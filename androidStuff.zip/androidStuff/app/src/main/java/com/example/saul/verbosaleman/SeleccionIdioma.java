package com.example.saul.verbosaleman;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SeleccionIdioma extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seleccion_idioma);

        Button btnP_EAl = findViewById(R.id.btnP_Al);
        btnP_EAl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent btnPrinc_Esp=new Intent(SeleccionIdioma.this,EspanolADeutsch.class);
                startActivity(btnPrinc_Esp);
            }
        });

        Button btnP_AEsp = findViewById(R.id.btnP_Esp);
        btnP_AEsp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent btnPrincp_AL=new Intent(SeleccionIdioma.this,DeustchAEspanol.class);
                startActivity(btnPrincp_AL);
            }
        });
    }
}
